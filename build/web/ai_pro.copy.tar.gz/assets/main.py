# import pygame
# from phase_01 import grid, draw_map, BLACK, GREEN, BLUE, PURPLE, RED, WHITE
# from phase_02 import zombies, goal_x, goal_y # Variables from Phase 02
# from phase_03 import get_path # AI Algorithms from Phase 03

# # --- DFS & CSP LOGIC ---
# def dfs_explore(start, limit=20):
#     """DFS algorithm for area exploration using a Stack."""
#     stack = [start]; visited = {start}; path = []
#     while stack and len(path) < limit:
#         curr = stack.pop(); path.append(curr)
#         for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
#             nxt = (curr[0]+dx, curr[1]+dy)
#             if 0 <= nxt[0] < 25 and 0 <= nxt[1] < 20 and grid[nxt[1]][nxt[0]] == 0:
#                 if nxt not in visited: 
#                     visited.add(nxt)
#                     stack.append(nxt)
#     return path

# def csp_decision(ammo_count):
#     """CSP logic to check bag capacity constraint."""
#     if ammo_count >= 3: return "⚠️ BAG FULL!", (255, 0, 0)
#     return f"✅ Slots: {3 - ammo_count}", (0, 255, 0)

# # --- INITIALIZATION ---
# pygame.init()
# screen = pygame.display.set_mode((750, 600))
# clock = pygame.time.Clock()
# font = pygame.font.SysFont("Arial", 20, bold=True)

# # Variables
# player_pos = [1, 1]
# current_ammo = 0  # Start with 0 ammo to encourage exploration
# z_speed_counter = 0 
# ai_path = []
# algo_name = ""
# msg, msg_col = "Find Ammo (Yellow Box) to survive zombies!", WHITE

# running = True
# while running:
#     screen.fill(BLACK)
#     draw_map(screen) # Rendering the maze from Phase 01

#     for event in pygame.event.get():
#         if event.type == pygame.QUIT: 
#             running = False
        
#         if event.type == pygame.KEYDOWN:
#             # AI Logic Triggers
#             if event.key == pygame.K_b: 
#                 ai_path = get_path("BFS", tuple(player_pos), (18, 4)); algo_name = "BFS"
#             if event.key == pygame.K_a: 
#                 ai_path = get_path("A*", tuple(player_pos), (goal_x, goal_y)); algo_name = "A*"
#             if event.key == pygame.K_d: 
#                 ai_path = dfs_explore(tuple(player_pos)); algo_name = "DFS"
#             if event.key == pygame.K_c: 
#                 msg, msg_col = csp_decision(current_ammo)

#             # Manual Movement with Wall Detection
#             nx, ny = player_pos
#             if event.key == pygame.K_w: ny -= 1
#             elif event.key == pygame.K_s: ny += 1
#             elif event.key == pygame.K_a: nx -= 1
#             elif event.key == pygame.K_d: nx += 1
#             if 0 <= nx < 25 and 0 <= ny < 20 and grid[ny][nx] == 0:
#                 player_pos = [nx, ny]

#     # --- AMMO PICKUP LOGIC ---
#     if tuple(player_pos) == (18, 4) and current_ammo < 3:
#         current_ammo += 1
#         msg, msg_col = f"Ammo Picked! Total: {current_ammo}", (0, 255, 255)

#     # --- ZOMBIE CHASE LOGIC ---
#     z_speed_counter += 1
#     if z_speed_counter > 15:
#         for z in zombies:
#             if z[0] < player_pos[0] and grid[z[1]][z[0]+1] == 0: z[0] += 1
#             elif z[0] > player_pos[0] and grid[z[1]][z[0]-1] == 0: z[0] -= 1
#             if z[1] < player_pos[1] and grid[z[1]+1][z[0]] == 0: z[1] += 1
#             elif z[1] > player_pos[1] and grid[z[1]-1][z[0]] == 0: z[1] -= 1
#         z_speed_counter = 0

#     # --- DEFENSE & COLLISION CHECK ---
#     for z in zombies[:]: # Use slice [:] to safely remove while iterating
#         if z[0] == player_pos[0] and z[1] == player_pos[1]:
#             if current_ammo > 0:
#                 # Combat Victory: Use 1 ammo to kill 1 zombie
#                 zombies.remove(z)
#                 current_ammo -= 1
#                 msg, msg_col = f"Zombie Killed! Ammo remaining: {current_ammo}", (0, 255, 0)
#             else:
#                 # Defeat: No ammo left
#                 msg, msg_col = "💀 NO AMMO! GAME OVER!", (255, 0, 0)
#                 screen.blit(font.render(msg, True, msg_col), (20, 565))
#                 pygame.display.flip()
#                 pygame.time.delay(2000)
#                 running = False 
    
#     # Win Condition
#     if tuple(player_pos) == (goal_x, goal_y):
#         msg, msg_col = "🏆 VICTORY! SAFEHOUSE REACHED!", (0, 255, 0)
#         screen.blit(font.render(msg, True, msg_col), (20, 565))
#         pygame.display.flip()
#         pygame.time.delay(2000)
#         running = False 

#     # Spacebar for Auto-Pilot
#     keys = pygame.key.get_pressed()
#     if keys[pygame.K_SPACE] and ai_path:
#         player_pos = list(ai_path.pop(0))

#     # --- DRAWING ---
#     # Draw AI Paths
#     p_color = (0,255,0) if algo_name=="BFS" else (0,0,255) if algo_name=="A*" else (255,255,0)
#     for step in ai_path:
#         pygame.draw.circle(screen, p_color, (step[0]*30+15, step[1]*30+15), 5)

#     # Draw Targets (Ammo & Safehouse)
#     pygame.draw.rect(screen, (255, 255, 0), (18 * 30, 4 * 30, 30, 30)) # Ammo Box
#     pygame.draw.rect(screen, BLUE, (goal_x * 30, goal_y * 30, 30, 30)) # Safehouse

#     # Draw Characters
#     pygame.draw.rect(screen, GREEN, (player_pos[0]*30, player_pos[1]*30, 30, 30))
#     for z in zombies: 
#         pygame.draw.circle(screen, PURPLE, (z[0]*30+15, z[1]*30+15), 12)

#     # Show UI Message
#     if msg: screen.blit(font.render(msg, True, msg_col), (20, 565))
    
#     pygame.display.flip() # Update entire screen
#     clock.tick(60)

# pygame.quit()


import pygame
import asyncio  # 1. Asyncio import karein
from phase_01 import grid, draw_map, BLACK, GREEN, BLUE, PURPLE, RED, WHITE
from phase_02 import zombies, goal_x, goal_y
from phase_03 import get_path

# --- DFS & CSP LOGIC (Functions wese hi rahengi) ---
def dfs_explore(start, limit=20):
    stack = [start]; visited = {start}; path = []
    while stack and len(path) < limit:
        curr = stack.pop(); path.append(curr)
        for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
            nxt = (curr[0]+dx, curr[1]+dy)
            if 0 <= nxt[0] < 25 and 0 <= nxt[1] < 20 and grid[nxt[1]][nxt[0]] == 0:
                if nxt not in visited: visited.add(nxt); stack.append(nxt)
    return path

def csp_decision(ammo_count):
    if ammo_count >= 3: return "⚠️ BAG FULL!", (255, 0, 0)
    return f"✅ Slots: {3 - ammo_count}", (0, 255, 0)

# 2. Poore game logic ko async function mein wrap karein
async def main():
    # --- INITIALIZATION ---
    pygame.init()
    screen = pygame.display.set_mode((750, 600))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 20, bold=True)

    # Variables
    player_pos = [1, 1]
    current_ammo = 0 
    z_speed_counter = 0 
    ai_path = []
    algo_name = ""
    msg, msg_col = "Find Ammo (Yellow Box) to survive zombies!", WHITE

    running = True
    while running:
        screen.fill(BLACK)
        draw_map(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: 
                running = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b: 
                    ai_path = get_path("BFS", tuple(player_pos), (18, 4)); algo_name = "BFS"
                if event.key == pygame.K_a: 
                    ai_path = get_path("A*", tuple(player_pos), (goal_x, goal_y)); algo_name = "A*"
                if event.key == pygame.K_d: 
                    ai_path = dfs_explore(tuple(player_pos)); algo_name = "DFS"
                if event.key == pygame.K_c: 
                    msg, msg_col = csp_decision(current_ammo)

                nx, ny = player_pos
                if event.key == pygame.K_w: ny -= 1
                elif event.key == pygame.K_s: ny += 1
                elif event.key == pygame.K_a: nx -= 1
                elif event.key == pygame.K_d: nx += 1
                if 0 <= nx < 25 and 0 <= ny < 20 and grid[ny][nx] == 0:
                    player_pos = [nx, ny]

        # --- Game Logics (Ammo, Zombies, Collision) ---
        if tuple(player_pos) == (18, 4) and current_ammo < 3:
            current_ammo += 1
            msg, msg_col = f"Ammo Picked! Total: {current_ammo}", (0, 255, 255)

        z_speed_counter += 1
        if z_speed_counter > 15:
            for z in zombies:
                if z[0] < player_pos[0] and grid[z[1]][z[0]+1] == 0: z[0] += 1
                elif z[0] > player_pos[0] and grid[z[1]][z[0]-1] == 0: z[0] -= 1
                if z[1] < player_pos[1] and grid[z[1]+1][z[0]] == 0: z[1] += 1
                elif z[1] > player_pos[1] and grid[z[1]-1][z[0]] == 0: z[1] -= 1
            z_speed_counter = 0

        for z in zombies[:]:
            if z[0] == player_pos[0] and z[1] == player_pos[1]:
                if current_ammo > 0:
                    zombies.remove(z)
                    current_ammo -= 1
                    msg, msg_col = f"Zombie Killed! Ammo: {current_ammo}", (0, 255, 0)
                else:
                    msg, msg_col = "💀 NO AMMO! GAME OVER!", (255, 0, 0)
                    screen.blit(font.render(msg, True, msg_col), (20, 565))
                    pygame.display.flip()
                    await asyncio.sleep(2) # Delay ke liye await istemaal karein
                    running = False
        
        if tuple(player_pos) == (goal_x, goal_y):
            msg, msg_col = "🏆 VICTORY! SAFEHOUSE REACHED!", (0, 255, 0)
            screen.blit(font.render(msg, True, msg_col), (20, 565))
            pygame.display.flip()
            await asyncio.sleep(2)
            running = False

        # Auto-Pilot logic
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and ai_path:
            player_pos = list(ai_path.pop(0))

        # --- DRAWING ---
        p_color = (0,255,0) if algo_name=="BFS" else (0,0,255) if algo_name=="A*" else (255,255,0)
        for step in ai_path:
            pygame.draw.circle(screen, p_color, (step[0]*30+15, step[1]*30+15), 5)
        
        pygame.draw.rect(screen, (255, 255, 0), (18 * 30, 4 * 30, 30, 30))
        pygame.draw.rect(screen, BLUE, (goal_x * 30, goal_y * 30, 30, 30))
        pygame.draw.rect(screen, GREEN, (player_pos[0]*30, player_pos[1]*30, 30, 30))
        for z in zombies: 
            pygame.draw.circle(screen, PURPLE, (z[0]*30+15, z[1]*30+15), 12)

        if msg: screen.blit(font.render(msg, True, msg_col), (20, 565))
        
        pygame.display.flip()
        clock.tick(60)
        
        # 3. YE LINE SAB SE ZAROORI HAI:
        await asyncio.sleep(0) 

    pygame.quit()

# 4. Program start karne ke liye:
asyncio.run(main())