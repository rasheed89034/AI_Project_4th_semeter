import heapq
from phase_01 import grid # Grid is necessary to check the path

def get_path(algo_type, start, target):
    """BFS and A* both work in this optimized function."""
    # for BFS use simple list and for A* use priority queue (heap)
    queue = [(start, [])] if algo_type == "BFS" else [(0, start, [])]
    visited = {start}

    while queue:
        if algo_type == "A*":
            _, current, path = heapq.heappop(queue)
        else:
            current, path = queue.pop(0)

        if current == target: 
            return path + [current]

        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nxt = (current[0] + dx, current[1] + dy)
            
            # Boundary and Wall check
            if 0 <= nxt[0] < 25 and 0 <= nxt[1] < 20 and grid[nxt[1]][nxt[0]] == 0:
                if nxt not in visited:
                    visited.add(nxt)
                    new_path = path + [current]
                    if algo_type == "BFS":
                        queue.append((nxt, new_path))
                    else:
                        # Manhattan Distance Heuristic: $d = |x_1 - x_2| + |y_1 - y_2|$
                        g = len(new_path)
                        h = abs(nxt[0] - target[0]) + abs(nxt[1] - target[1])
                        heapq.heappush(queue, (g + h, nxt, new_path))
    return []

if __name__ == "__main__":
    print("AI Toolbox (Phase 03) is ready.")