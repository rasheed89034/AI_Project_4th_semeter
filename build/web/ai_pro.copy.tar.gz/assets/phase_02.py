import pygame
import random
from phase_01 import grid, draw_map, BLACK, GREEN, BLUE, PURPLE

pygame.init()
screen = pygame.display.set_mode((750, 600))
clock = pygame.time.Clock()

# Positions & Stats
px, py = 0, 0
goal_x, goal_y = 24, 19
php = 100
running = True
z_speed = 0

# Zombies setup
zombies = []
while len(zombies) < 5:
    zx, zy = random.randint(5, 24), random.randint(5, 19)
    if grid[zy][zx] == 0: 
        zombies.append([zx, zy])

def start_game_logic():
    # these variables are necessary to update the values that's why we declare them global
    global px, py, php, running, z_speed

    while running:
        screen.fill(BLACK)
        pygame.display.set_caption(f"HP: {php}")

        for event in pygame.event.get():
            if event.type == pygame.QUIT: 
                running = False
            
            if event.type == pygame.KEYDOWN:
                nx, ny = px, py
                if event.key == pygame.K_w: ny -= 1
                if event.key == pygame.K_s: ny += 1
                if event.key == pygame.K_a: nx -= 1
                if event.key == pygame.K_d: nx += 1
                
                # Boundary aur Wall check
                if 0 <= nx < 25 and 0 <= ny < 20 and grid[ny][nx] == 0:
                    px, py = nx, ny

        # Zombie movement logic
        z_speed += 1
        if z_speed > 10:
            for z in zombies:
                if z[0] < px and grid[z[1]][z[0]+1] == 0: z[0] += 1
                elif z[0] > px and grid[z[1]][z[0]-1] == 0: z[0] -= 1
                if z[1] < py and grid[z[1]+1][z[0]] == 0: z[1] += 1
                elif z[1] > py and grid[z[1]-1][z[0]] == 0: z[1] -= 1
            z_speed = 0

        # Drawing
        draw_map(screen) 
        pygame.draw.rect(screen, BLUE, (goal_x*30, goal_y*30, 30, 30))
        pygame.draw.rect(screen, GREEN, (px*30, py*30, 30, 30))
        for z in zombies:
            pygame.draw.circle(screen, PURPLE, (z[0]*30+15, z[1]*30+15), 12)

        # Collision Check
        if any(z[0] == px and z[1] == py for z in zombies):
            php -= 1
            if php <= 0: 
                print("Game Over!")
                running = False

        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit() # quit the game

if __name__ == "__main__":
    start_game_logic()